#!/bin/bash
echo "Installing Sovereign Ignition CLI dependencies..."
# Example: install Node.js packages if needed
# npm install (optional future step)
echo "Setup complete. Use 'sovereign-cli --help' for usage instructions."